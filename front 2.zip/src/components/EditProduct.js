import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/api";
import { TextField, Button, Container, Typography } from "@mui/material";

const EditProduct = () => {
  const { id } = useParams();  // Pega o ID do produto da URL
  const navigate = useNavigate();  // Hook de navegação para voltar para a lista de produtos
  const [product, setProduct] = useState({
    nome: "",
    descricao: "",
    preco: "",
    estoque: ""
  });

  useEffect(() => {
    // Função para buscar os dados do produto a ser editado
    const fetchProduct = async () => {
      try {
        const response = await api.get(`/products/${id}`);
        setProduct(response.data);
      } catch (error) {
        console.error("Erro ao buscar o produto:", error);
      }
    };
    fetchProduct();
  }, [id]);

  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      const response = await api.put(`/products/${id}`, product);
      navigate("/");  // Redireciona para a lista de produtos após editar
    } catch (error) {
      console.error("Erro ao atualizar o produto:", error);
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" gutterBottom>
        Editar Produto
      </Typography>
      <form onSubmit={handleUpdateProduct}>
        <TextField
          fullWidth
          label="Nome"
          variant="outlined"
          value={product.nome}
          onChange={(e) => setProduct({ ...product, nome: e.target.value })}
        />
        <TextField
          fullWidth
          label="Descrição"
          variant="outlined"
          value={product.descricao}
          onChange={(e) => setProduct({ ...product, descricao: e.target.value })}
        />
        <TextField
          fullWidth
          label="Preço"
          variant="outlined"
          type="number"
          value={product.preco}
          onChange={(e) => setProduct({ ...product, preco: e.target.value })}
        />
        <TextField
          fullWidth
          label="Estoque"
          variant="outlined"
          type="number"
          value={product.estoque}
          onChange={(e) => setProduct({ ...product, estoque: e.target.value })}
        />
        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          Atualizar Produto
        </Button>
      </form>
    </Container>
  );
};

export default EditProduct;
